MAJORVER=12
echo  "/u01/pg"${MAJORVER}"/data /u02/archive /u02/backup"

