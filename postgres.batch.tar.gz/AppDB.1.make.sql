--# create 
create database appdb encoding 'UTF8'  LC_COLLATE='en_US.UTF8';
